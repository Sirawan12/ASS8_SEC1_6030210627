package com.example.lab7dialogrv_sec1_603021062_7

data class Student (val id:String, val name: String, val age: Int) {
}